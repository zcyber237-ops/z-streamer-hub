import EnvironmentConfig from '../config/environment.js';
import ErrorHandler from '../utils/errorHandler.js';
import InputValidator from '../utils/inputValidator.js';

/**
 * Secure API service that proxies requests through backend
 * NO SENSITIVE KEYS ON FRONTEND
 */
class ApiService {
    constructor() {
        this.baseUrl = EnvironmentConfig.get('apiUrl');
        this.timeout = EnvironmentConfig.get('streamTimeout');
    }

    /**
     * Generic API request method with security headers
     * @param {string} endpoint - API endpoint
     * @param {object} options - Request options
     * @returns {Promise}
     */
    async request(endpoint, options = {}) {
        const url = `${this.baseUrl}${endpoint}`;
        
        const defaultOptions = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            credentials: 'same-origin',
            ...options
        };

        // Add CSRF token if available
        const csrfToken = this.getCSRFToken();
        if (csrfToken) {
            defaultOptions.headers['X-CSRF-Token'] = csrfToken;
        }

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), this.timeout);

        try {
            const response = await fetch(url, {
                ...defaultOptions,
                signal: controller.signal
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
                throw new Error(`API Error: ${response.status} ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            clearTimeout(timeoutId);
            
            if (error.name === 'AbortError') {
                throw new Error('Request timeout');
            }
            
            throw error;
        }
    }

    /**
     * Send chat message to AI service via backend proxy
     * @param {string} message - User message
     * @returns {Promise}
     */
    async sendChatMessage(message) {
        const validation = InputValidator.validateChatInput(message);
        if (!validation.valid) {
            throw new Error(validation.error);
        }

        return ErrorHandler.withRetry(async () => {
            return await this.request('/ai/chat', {
                method: 'POST',
                body: JSON.stringify({
                    message: validation.sanitized,
                    timestamp: new Date().toISOString()
                })
            });
        }, 2, 1000);
    }

    /**
     * Validate stream URL via backend
     * @param {string} url - Stream URL to validate
     * @returns {Promise}
     */
    async validateStreamUrl(url) {
        if (!InputValidator.validateStreamUrl(url)) {
            throw new Error('Invalid stream URL format');
        }

        return await this.request('/streams/validate', {
            method: 'POST',
            body: JSON.stringify({ url })
        });
    }

    /**
     * Get stream metadata
     * @param {string} url - Stream URL
     * @returns {Promise}
     */
    async getStreamMetadata(url) {
        if (!InputValidator.validateStreamUrl(url)) {
            throw new Error('Invalid stream URL format');
        }

        return await this.request(`/streams/metadata?url=${encodeURIComponent(url)}`);
    }

    /**
     * Report stream error for analytics
     * @param {object} errorData - Error information
     * @returns {Promise}
     */
    async reportStreamError(errorData) {
        try {
            await this.request('/analytics/stream-error', {
                method: 'POST',
                body: JSON.stringify({
                    ...errorData,
                    timestamp: new Date().toISOString(),
                    userAgent: navigator.userAgent,
                    url: window.location.href
                })
            });
        } catch (error) {
            // Don't throw errors for analytics - just log
            console.warn('Failed to report stream error:', error);
        }
    }

    /**
     * Get CSRF token from meta tag or cookie
     * @returns {string|null}
     */
    getCSRFToken() {
        // Try to get from meta tag first
        const metaToken = document.querySelector('meta[name="csrf-token"]');
        if (metaToken) {
            return metaToken.getAttribute('content');
        }

        // Fallback to cookie
        const cookies = document.cookie.split(';');
        const csrfCookie = cookies.find(cookie => cookie.trim().startsWith('csrf_token='));
        if (csrfCookie) {
            return csrfCookie.split('=')[1];
        }

        return null;
    }
}

export default new ApiService();
