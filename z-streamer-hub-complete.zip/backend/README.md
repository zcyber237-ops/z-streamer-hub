# StreamHub Backend API

## Environment Variables

Create a `.env` file in the backend directory with the following variables:

```env
# Server Configuration
PORT=3001
NODE_ENV=production

# Frontend Configuration
FRONTEND_URL=https://your-frontend-domain.com

# API Keys (Keep these secret!)
GEMINI_API_KEY=your_actual_gemini_api_key_here

# Database Configuration (if using)
DATABASE_URL=your_database_connection_string

# Security
JWT_SECRET=your_super_secret_jwt_key
CORS_ORIGINS=https://your-frontend-domain.com,https://another-allowed-domain.com

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# Analytics
ANALYTICS_API_KEY=your_analytics_service_key
```

## Installation

```bash
npm install express cors helmet express-rate-limit express-validator dotenv
```

## Deployment

### Using PM2 (Production)

```bash
npm install -g pm2
pm2 start server.js --name "streamhub-api"
pm2 startup
pm2 save
```

### Using Docker

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3001
CMD ["node", "server.js"]
```

### Using Heroku

```bash
heroku create streamhub-api
heroku config:set NODE_ENV=production
heroku config:set GEMINI_API_KEY=your_key_here
git push heroku main
```

## API Endpoints

### POST /api/ai/chat
Proxy AI chat requests to Gemini API
- Body: `{ message: string, timestamp: string }`
- Response: `{ message: string, sources: array, timestamp: string }`

### POST /api/streams/validate
Validate stream URLs
- Body: `{ url: string }`
- Response: `{ valid: boolean, status: number, contentType: string }`

### GET /api/streams/metadata
Get stream metadata
- Query: `url=https://example.com/stream.mp4`
- Response: `{ url: string, accessible: boolean, headers: object }`

### POST /api/analytics/stream-error
Report stream errors for analytics
- Body: `{ code: number, message: string, streamUrl: string }`
- Response: `{ success: boolean }`

### GET /api/health
Health check endpoint
- Response: `{ status: string, timestamp: string, version: string }`

## Security Features

- Helmet.js for security headers
- CORS protection
- Rate limiting
- Input validation and sanitization
- Environment-based configuration
- Error handling without information leakage

## Monitoring

Recommended monitoring tools:
- New Relic or DataDog for APM
- LogRocket or Sentry for error tracking
- Uptime Robot for availability monitoring
