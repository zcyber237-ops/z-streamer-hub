module.exports = {
    testEnvironment: 'jsdom',
    setupFilesAfterEnv: ['<rootDir>/tests/setup.js'],
    moduleNameMapping: {
        '^@/(.*)$': '<rootDir>/src/$1'
    },
    transform: {
        '^.+\\.(js|jsx)$': 'babel-jest'
    },
    collectCoverageFrom: [
        'src/**/*.{js,jsx}',
        '!src/**/*.test.{js,jsx}',
        '!src/main.js' // Exclude main app file from coverage
    ],
    coverageReporters: [
        'text',
        'lcov',
        'html'
    ],
    testMatch: [
        '<rootDir>/tests/**/*.test.{js,jsx}'
    ],
    moduleFileExtensions: [
        'js',
        'jsx',
        'json'
    ],
    globals: {
        'window': {},
        'document': {}
    }
};
