/**
 * Example Express.js backend API implementation
 * This would be deployed separately from the frontend
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { body, validationResult, param } = require('express-validator');
const app = express();

// Environment configuration
require('dotenv').config();

// Security middleware
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            scriptSrc: ["'self'", "'unsafe-inline'", "https://cdn.tailwindcss.com"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
            imgSrc: ["'self'", "data:", "https:"],
            mediaSrc: ["'self'", "https:", "blob:"],
            connectSrc: ["'self'", "https:"],
        },
    },
}));

// CORS configuration
app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true,
    optionsSuccessStatus: 200
}));

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Limit each IP to 100 requests per windowMs
    message: 'Too many requests from this IP, please try again later.',
    standardHeaders: true,
    legacyHeaders: false,
});
app.use('/api/', limiter);

// Body parser middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// API Routes

/**
 * AI Chat Endpoint - Proxies requests to Gemini API
 */
app.post('/api/ai/chat', [
    body('message')
        .isLength({ min: 1, max: 1000 })
        .withMessage('Message must be between 1 and 1000 characters')
        .escape(),
    body('timestamp')
        .isISO8601()
        .withMessage('Invalid timestamp format')
], async (req, res) => {
    try {
        // Validate input
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: 'Validation failed',
                details: errors.array()
            });
        }

        const { message } = req.body;
        
        // Check API key
        if (!process.env.GEMINI_API_KEY) {
            return res.status(500).json({
                error: 'AI service not configured'
            });
        }

        // Make request to Gemini API
        const geminiResponse = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-05-20:generateContent?key=${process.env.GEMINI_API_KEY}`,
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: message }] }],
                    tools: [{ "google_search": {} }],
                    systemInstruction: {
                        parts: [{
                            text: "You are a helpful and knowledgeable Cross-Platform Streaming Media Engineer AI. Answer the user's question concisely using web grounding if necessary. Focus on topics like HLS, M3U8, MIME types, and streaming protocols."
                        }]
                    },
                })
            }
        );

        if (!geminiResponse.ok) {
            throw new Error(`Gemini API error: ${geminiResponse.status}`);
        }

        const geminiData = await geminiResponse.json();
        const responseText = geminiData.candidates?.[0]?.content?.parts?.[0]?.text || 
                           "Sorry, I couldn't generate a response.";

        // Extract sources if available
        const sources = geminiData.candidates?.[0]?.groundingMetadata?.webSearchQueries || [];

        res.json({
            message: responseText,
            sources: sources,
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error('AI Chat Error:', error);
        res.status(500).json({
            error: 'AI service temporarily unavailable',
            message: 'Please try again later'
        });
    }
});

/**
 * Stream Validation Endpoint
 */
app.post('/api/streams/validate', [
    body('url')
        .isURL({ protocols: ['http', 'https'] })
        .withMessage('Invalid URL format')
        .isLength({ max: 2000 })
        .withMessage('URL too long')
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: 'Validation failed',
                details: errors.array()
            });
        }

        const { url } = req.body;
        
        // Basic URL validation
        const allowedExtensions = ['.mp4', '.mov', '.m3u8', '.webm', '.avi', '.mkv'];
        const urlLower = url.toLowerCase();
        
        const isValidExtension = allowedExtensions.some(ext => urlLower.includes(ext));
        const isStreamUrl = urlLower.includes('stream') || urlLower.includes('video');
        
        if (!isValidExtension && !isStreamUrl) {
            return res.status(400).json({
                valid: false,
                error: 'URL does not appear to be a valid video stream'
            });
        }

        // Try to fetch headers to validate the URL
        try {
            const response = await fetch(url, { method: 'HEAD', timeout: 5000 });
            const contentType = response.headers.get('content-type') || '';
            const contentLength = response.headers.get('content-length');
            
            res.json({
                valid: response.ok,
                status: response.status,
                contentType,
                contentLength,
                accessible: response.ok
            });
        } catch (fetchError) {
            res.json({
                valid: false,
                error: 'URL is not accessible',
                details: fetchError.message
            });
        }

    } catch (error) {
        console.error('Stream validation error:', error);
        res.status(500).json({
            error: 'Validation service error'
        });
    }
});

/**
 * Stream Metadata Endpoint
 */
app.get('/api/streams/metadata', [
    param('url')
        .isURL({ protocols: ['http', 'https'] })
        .withMessage('Invalid URL format')
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: 'Validation failed',
                details: errors.array()
            });
        }

        const { url } = req.query;
        
        // Fetch stream metadata
        try {
            const response = await fetch(url, { method: 'HEAD', timeout: 10000 });
            
            const metadata = {
                url,
                accessible: response.ok,
                status: response.status,
                headers: {
                    contentType: response.headers.get('content-type'),
                    contentLength: response.headers.get('content-length'),
                    lastModified: response.headers.get('last-modified'),
                    server: response.headers.get('server'),
                    acceptRanges: response.headers.get('accept-ranges')
                },
                isLive: response.headers.get('content-type')?.includes('mpegurl') || url.includes('.m3u8'),
                estimatedDuration: null, // Would require deeper analysis
                quality: null, // Would require stream analysis
                timestamp: new Date().toISOString()
            };
            
            res.json(metadata);
        } catch (fetchError) {
            res.status(404).json({
                error: 'Stream not accessible',
                details: fetchError.message
            });
        }

    } catch (error) {
        console.error('Metadata fetch error:', error);
        res.status(500).json({
            error: 'Metadata service error'
        });
    }
});

/**
 * Analytics Endpoint - Stream Error Reporting
 */
app.post('/api/analytics/stream-error', [
    body('code').optional().isNumeric(),
    body('message').isLength({ max: 500 }).escape(),
    body('streamUrl').optional().isURL(),
    body('playerType').optional().isIn(['main', 'dedicated']),
    body('timestamp').isISO8601()
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: 'Validation failed',
                details: errors.array()
            });
        }

        const errorData = req.body;
        
        // Log error for analytics (in production, send to analytics service)
        console.log('Stream Error Analytics:', {
            ...errorData,
            ip: req.ip,
            userAgent: req.get('User-Agent'),
            timestamp: new Date().toISOString()
        });
        
        // In a real application, you would:
        // - Send to analytics service (Google Analytics, Mixpanel, etc.)
        // - Store in database for analysis
        // - Trigger alerts for critical errors
        
        res.json({
            success: true,
            message: 'Error report received'
        });

    } catch (error) {
        console.error('Analytics error:', error);
        res.status(500).json({
            error: 'Analytics service error'
        });
    }
});

/**
 * Health Check Endpoint
 */
app.get('/api/health', (req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        version: process.env.npm_package_version || '1.0.0',
        environment: process.env.NODE_ENV || 'development'
    });
});

// Error handling middleware
app.use((error, req, res, next) => {
    console.error('Unhandled error:', error);
    res.status(500).json({
        error: 'Internal server error',
        message: process.env.NODE_ENV === 'development' ? error.message : 'Something went wrong'
    });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        error: 'Not found',
        message: 'The requested endpoint does not exist'
    });
});

const PORT = process.env.PORT || 3001;

app.listen(PORT, () => {
    console.log(`StreamHub API server running on port ${PORT}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});

module.exports = app;
