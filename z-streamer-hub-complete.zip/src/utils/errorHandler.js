/**
 * Centralized error handling and logging
 */
class ErrorHandler {
    constructor() {
        this.setupGlobalHandlers();
    }

    setupGlobalHandlers() {
        // Handle unhandled promise rejections
        window.addEventListener('unhandledrejection', (event) => {
            this.handleError(event.reason, { type: 'unhandledRejection' });
            event.preventDefault();
        });

        // Handle JavaScript errors
        window.addEventListener('error', (event) => {
            this.handleError(event.error, {
                type: 'javascript',
                filename: event.filename,
                line: event.lineno,
                column: event.colno
            });
        });
    }

    /**
     * Handle errors with retry capability
     * @param {Function} fn - Function to execute
     * @param {number} maxRetries - Maximum retry attempts
     * @param {number} backoffMs - Backoff time in milliseconds
     * @returns {Promise}
     */
    static async withRetry(fn, maxRetries = 3, backoffMs = 1000) {
        let lastError;
        
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                return await fn();
            } catch (error) {
                lastError = error;
                
                if (attempt === maxRetries) {
                    throw new Error(`Failed after ${maxRetries} attempts: ${error.message}`);
                }
                
                // Exponential backoff
                const delay = backoffMs * Math.pow(2, attempt - 1);
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }
    }

    /**
     * Handle stream-specific errors
     * @param {Error} error - Error object
     * @param {string} streamUrl - URL of the stream that failed
     * @returns {string} User-friendly error message
     */
    static handleStreamError(error, streamUrl = '') {
        const errorMap = {
            'NETWORK_ERROR': 'Network connectivity issue. Please check your internet connection.',
            'MEDIA_ERROR': 'Media format not supported or file is corrupted.',
            'CORS_ERROR': 'Cross-origin restriction. Stream may require different configuration.',
            'TIMEOUT_ERROR': 'Request timeout. The server may be slow or unreachable.',
            'MANIFEST_LOAD_ERROR': 'Failed to load stream manifest. URL may be invalid.',
            'BUFFER_STALLED_ERROR': 'Playback stalled due to buffering issues.',
            'DECODE_ERROR': 'Failed to decode video stream.',
            'FORMAT_ERROR': 'Unsupported video format or codec.'
        };

        let errorType = 'UNKNOWN_ERROR';
        const errorMessage = error?.message?.toLowerCase() || '';

        // Map common error messages to types
        if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
            errorType = 'NETWORK_ERROR';
        } else if (errorMessage.includes('cors')) {
            errorType = 'CORS_ERROR';
        } else if (errorMessage.includes('timeout')) {
            errorType = 'TIMEOUT_ERROR';
        } else if (errorMessage.includes('manifest')) {
            errorType = 'MANIFEST_LOAD_ERROR';
        } else if (errorMessage.includes('decode')) {
            errorType = 'DECODE_ERROR';
        } else if (errorMessage.includes('format') || errorMessage.includes('codec')) {
            errorType = 'FORMAT_ERROR';
        }

        const userMessage = errorMap[errorType] || `An unexpected error occurred: ${error.message}`;
        
        // Log detailed error for debugging
        console.error('Stream Error Details:', {
            type: errorType,
            originalMessage: error.message,
            streamUrl,
            stack: error.stack,
            timestamp: new Date().toISOString()
        });

        return userMessage;
    }

    /**
     * Handle general application errors
     * @param {Error} error - Error object
     * @param {object} context - Additional context
     */
    handleError(error, context = {}) {
        const errorData = {
            message: error?.message || 'Unknown error',
            stack: error?.stack,
            url: window.location.href,
            userAgent: navigator.userAgent,
            timestamp: new Date().toISOString(),
            context
        };

        // Log to console in development
        if (process.env.NODE_ENV === 'development') {
            console.error('Application Error:', errorData);
        }

        // In production, send to monitoring service
        this.sendToMonitoring(errorData);
    }

    /**
     * Send error data to monitoring service
     * @param {object} errorData - Error information
     */
    sendToMonitoring(errorData) {
        // In a real application, this would send to a service like Sentry, LogRocket, etc.
        // For now, we'll just log it
        if (window.console && window.console.error) {
            console.error('Error tracked:', errorData);
        }

        // Could implement:
        // - Send to external logging service
        // - Store in localStorage for offline scenarios
        // - Send analytics events
    }
}

export default new ErrorHandler();
