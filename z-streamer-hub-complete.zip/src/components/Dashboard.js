import AppState from '../state/appState.js';
import InputValidator from '../utils/inputValidator.js';

/**
 * Dashboard Component for managing content display
 */
class Dashboard {
    constructor(containerId) {
        this.containerId = containerId;
        this.container = document.getElementById(containerId);
        
        if (!this.container) {
            throw new Error(`Dashboard container ${containerId} not found`);
        }
        
        this.regionalContent = {
            USA: [
                { title: "Paid: US Blockbusters (MP4)", type: "movie", items: [
                    { id: "usa-001", title: "Big Buck Bunny Trailer", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", poster: "https://placehold.co/300x168/FF4500/ffffff?text=USA+PAID", description: "Standard MP4 Test File." },
                    { id: "usa-002", title: "Tears of Steel", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4", poster: "https://placehold.co/300x168/00BFFF/ffffff?text=USA+PREMIUM", description: "High-quality MP4 file." },
                ]},
                { title: "Free: US HLS Channels", type: "hls", items: [
                    { id: "usa-hls-001", title: "Mux Test Stream (HLS)", url: "https://stream.mux.com/v69RSHhFelmE9yP2mj2DGMsFI.m3u8", poster: "https://placehold.co/300x168/4B0082/ffffff?text=US+FREE+HLS", description: "Reliable HLS Test Stream." },
                    { id: "usa-mock-1", title: "US Failed Stream (Mock)", url: "https://this-stream-is-fake-and-will-fail.com/video.mp4", poster: "https://placehold.co/300x168/8B0000/ffffff?text=MOCK+FAIL+TEST", description: "A simulated failed stream for AI diagnosis testing." },
                ]}
            ],
            Europe: [
                { title: "Paid: European Films (MP4)", type: "movie", items: [
                    { id: "eur-001", title: "Sintel Short Film", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4", poster: "https://placehold.co/300x168/DAA520/000000?text=EUR+PREMIUM", description: "Vibrant animated short film." },
                ]},
                { title: "Free: European HLS Channels", type: "hls", items: [
                    { id: "eur-hls-001", title: "Apple Test Stream (HLS)", url: "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8", poster: "https://placehold.co/300x168/228B22/ffffff?text=EUR+FREE+HLS", description: "Standard Apple HLS Example." },
                ]}
            ],
            Africa: [
                { title: "Paid: African Content (MP4)", type: "movie", items: [
                    { id: "afr-001", title: "For Bigger Blazes", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4", poster: "https://placehold.co/300x168/800080/ffffff?text=AFR+PAID", description: "Short advertising content." },
                ]},
                { title: "Free: African HLS Channels", type: "hls", items: [
                    { id: "afr-hls-001", title: "Example M3U8 1", url: "https://stream.mux.com/v69RSHhFelmE9yP2mj2DGMsFI.m3u8", poster: "https://placehold.co/300x168/FFA07A/000000?text=AFR+FREE+HLS", description: "Reliable HLS Test Stream." },
                ]}
            ]
        };
        
        this.intersectionObserver = null;
        this.initialize();
    }

    /**
     * Initialize the dashboard
     */
    initialize() {
        // Subscribe to state changes
        AppState.subscribe('activeRegion', (region) => {
            this.render();
        });
        
        AppState.subscribe('watchlist', () => {
            this.render();
        });
        
        // Set up lazy loading for images
        this.setupLazyLoading();
        
        // Initial render
        this.render();
    }

    /**
     * Set up intersection observer for lazy loading images
     */
    setupLazyLoading() {
        if ('IntersectionObserver' in window) {
            this.intersectionObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        if (img.dataset.src) {
                            img.src = img.dataset.src;
                            img.classList.remove('lazy-load');
                            img.classList.add('lazy-loaded');
                            this.intersectionObserver.unobserve(img);
                        }
                    }
                });
            }, {
                rootMargin: '50px 0px',
                threshold: 0.1
            });
        }
    }

    /**
     * Render the dashboard content
     */
    render() {
        const activeRegion = AppState.get('activeRegion');
        const watchlist = AppState.get('watchlist');
        const content = this.regionalContent[activeRegion] || [];
        
        this.container.innerHTML = '';
        
        content.forEach(row => {
            const rowElement = this.createRowElement(row, watchlist);
            this.container.appendChild(rowElement);
        });
        
        // Re-observe lazy load images
        this.observeLazyImages();
    }

    /**
     * Create a content row element
     * @param {object} row - Row data
     * @param {Map} watchlist - Current watchlist
     * @returns {HTMLElement}
     */
    createRowElement(row, watchlist) {
        const rowDiv = document.createElement('div');
        rowDiv.className = 'content-row mb-12';
        
        const title = document.createElement('h2');
        title.className = 'text-2xl font-bold mb-4 text-white';
        title.textContent = row.title;
        
        const grid = document.createElement('div');
        grid.className = 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4';
        
        row.items.forEach(item => {
            const card = this.createStreamCard(item, watchlist);
            grid.appendChild(card);
        });
        
        rowDiv.appendChild(title);
        rowDiv.appendChild(grid);
        
        return rowDiv;
    }

    /**
     * Create a stream card element
     * @param {object} item - Stream item
     * @param {Map} watchlist - Current watchlist
     * @returns {HTMLElement}
     */
    createStreamCard(item, watchlist) {
        const isInWatchlist = watchlist && watchlist.has(item.id);
        
        const card = document.createElement('div');
        card.className = 'stream-card bg-cardBg rounded-lg overflow-hidden shadow-lg transform hover:scale-105 transition duration-300';
        
        // Sanitize item data
        const sanitizedTitle = InputValidator.sanitizeText(item.title);
        const sanitizedDescription = InputValidator.sanitizeText(item.description);
        
        card.innerHTML = `
            <div class="relative">
                <img 
                    class="w-full h-auto object-cover lazy-load" 
                    data-src="${item.poster}" 
                    alt="${sanitizedTitle}"
                    loading="lazy"
                    src="data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 300 168'%3e%3crect width='100%25' height='100%25' fill='%23404040'/%3e%3ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' fill='%23ffffff' font-family='Arial, sans-serif' font-size='14'%3eLoading...%3c/text%3e%3c/svg%3e"
                />
                <div class="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center opacity-0 hover:opacity-100 transition duration-300">
                    <button 
                        class="play-button bg-white text-black font-bold py-2 px-4 rounded-full shadow-lg flex items-center space-x-2"
                        aria-label="Play ${sanitizedTitle}"
                        data-stream-id="${item.id}"
                        data-stream-title="${sanitizedTitle}"
                        data-stream-url="${item.url}"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clip-rule="evenodd" />
                        </svg>
                        <span>Play</span>
                    </button>
                </div>
            </div>
            <div class="p-4">
                <h4 class="text-lg font-semibold truncate text-white mb-2" title="${sanitizedTitle}">${sanitizedTitle}</h4>
                <p class="text-xs text-gray-400 mb-3">${sanitizedDescription}</p>
                <button 
                    class="watchlist-button w-full text-sm font-semibold py-2 px-4 rounded transition duration-150 ${
                        isInWatchlist ? 'bg-red-700 hover:bg-red-600' : 'bg-green-600 hover:bg-green-500'
                    }"
                    data-stream-id="${item.id}"
                    data-action="${isInWatchlist ? 'remove' : 'add'}"
                    aria-label="${isInWatchlist ? 'Remove from' : 'Add to'} watchlist"
                >
                    ${isInWatchlist ? '✓ Remove' : '+ My List'}
                </button>
            </div>
        `;
        
        // Add event listeners
        this.attachCardEventListeners(card, item);
        
        return card;
    }

    /**
     * Attach event listeners to card elements
     * @param {HTMLElement} card - Card element
     * @param {object} item - Stream item data
     */
    attachCardEventListeners(card, item) {
        // Play button
        const playButton = card.querySelector('.play-button');
        if (playButton) {
            playButton.addEventListener('click', (e) => {
                e.preventDefault();
                this.handlePlayStream(item);
            });
        }
        
        // Watchlist button
        const watchlistButton = card.querySelector('.watchlist-button');
        if (watchlistButton) {
            watchlistButton.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleWatchlistAction(item, watchlistButton.dataset.action);
            });
        }
    }

    /**
     * Handle play stream action
     * @param {object} item - Stream item
     */
    handlePlayStream(item) {
        // Validate stream URL before playing
        if (!InputValidator.validateStreamUrl(item.url)) {
            this.showNotification('Invalid stream URL', 'error');
            return;
        }
        
        // Dispatch custom event for play action
        const event = new CustomEvent('dashboard:play-stream', {
            detail: {
                id: item.id,
                title: item.title,
                url: item.url
            }
        });
        
        document.dispatchEvent(event);
    }

    /**
     * Handle watchlist add/remove action
     * @param {object} item - Stream item
     * @param {string} action - 'add' or 'remove'
     */
    handleWatchlistAction(item, action) {
        const event = new CustomEvent('dashboard:watchlist-action', {
            detail: {
                action,
                item
            }
        });
        
        document.dispatchEvent(event);
    }

    /**
     * Observe lazy load images
     */
    observeLazyImages() {
        if (!this.intersectionObserver) return;
        
        const lazyImages = this.container.querySelectorAll('.lazy-load');
        lazyImages.forEach(img => {
            this.intersectionObserver.observe(img);
        });
    }

    /**
     * Show notification
     * @param {string} message - Message to show
     * @param {string} type - Notification type
     */
    showNotification(message, type = 'info') {
        if (window.showMessage) {
            window.showMessage(message, type === 'error');
        } else {
            console.log(`${type.toUpperCase()}: ${message}`);
        }
    }

    /**
     * Cleanup and dispose
     */
    dispose() {
        if (this.intersectionObserver) {
            this.intersectionObserver.disconnect();
        }
    }
}

export default Dashboard;
