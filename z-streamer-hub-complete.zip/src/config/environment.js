// Environment configuration - NO SENSITIVE DATA HERE
class EnvironmentConfig {
    constructor() {
        this.env = this.detectEnvironment();
        this.config = this.getConfig();
    }

    detectEnvironment() {
        if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
            return 'development';
        }
        if (window.location.hostname.includes('staging')) {
            return 'staging';
        }
        return 'production';
    }

    getConfig() {
        const configs = {
            development: {
                apiUrl: '/api',  // Proxy to backend
                enableLogging: true,
                enableAnalytics: false,
                streamTimeout: 30000
            },
            staging: {
                apiUrl: '/api',
                enableLogging: true,
                enableAnalytics: true,
                streamTimeout: 30000
            },
            production: {
                apiUrl: '/api',
                enableLogging: false,
                enableAnalytics: true,
                streamTimeout: 15000
            }
        };

        return configs[this.env];
    }

    get(key) {
        return this.config[key];
    }
}

export default new EnvironmentConfig();
