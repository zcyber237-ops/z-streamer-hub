import ApiService from '../services/apiService.js';
import ErrorHandler from '../utils/errorHandler.js';
import InputValidator from '../utils/inputValidator.js';
import AppState from '../state/appState.js';

/**
 * Video Player Component with HLS support and error handling
 */
class VideoPlayer {
    constructor(containerId, options = {}) {
        this.containerId = containerId;
        this.options = {
            autoplay: false,
            controls: true,
            responsive: true,
            fill: true,
            liveui: true,
            ...options
        };
        
        this.player = null;
        this.hls = null;
        this.currentStream = null;
        this.isDedicated = options.isDedicated || false;
        
        this.initialize();
    }

    /**
     * Initialize the video player
     */
    async initialize() {
        try {
            // Wait for Video.js to be available
            await this.waitForVideoJS();
            
            // Initialize Video.js player
            this.player = videojs(this.containerId, this.options);
            
            // Set up event listeners
            this.setupEventListeners();
            
            // Update state
            AppState.set('streamStatus.playerReady', true);
            
            console.log('Video player initialized successfully');
        } catch (error) {
            console.error('Failed to initialize video player:', error);
            ErrorHandler.handleError(error, { component: 'VideoPlayer' });
        }
    }

    /**
     * Wait for Video.js library to be available
     */
    async waitForVideoJS() {
        return new Promise((resolve, reject) => {
            let attempts = 0;
            const maxAttempts = 50;
            
            const checkVideoJS = () => {
                if (window.videojs) {
                    resolve();
                } else if (attempts >= maxAttempts) {
                    reject(new Error('Video.js library not available'));
                } else {
                    attempts++;
                    setTimeout(checkVideoJS, 100);
                }
            };
            
            checkVideoJS();
        });
    }

    /**
     * Set up player event listeners
     */
    setupEventListeners() {
        if (!this.player) return;

        // Error handling
        this.player.on('error', () => {
            const error = this.player.error();
            if (error) {
                const errorMessage = ErrorHandler.handleStreamError(error, this.currentStream);
                this.showNotification(errorMessage, 'error');
                
                // Report error for analytics
                ApiService.reportStreamError({
                    code: error.code,
                    message: error.message,
                    streamUrl: this.currentStream,
                    playerType: this.isDedicated ? 'dedicated' : 'main'
                });
            }
        });

        // Loading events
        this.player.on('loadstart', () => {
            AppState.set('ui.isLoading', true);
        });

        this.player.on('canplay', () => {
            AppState.set('ui.isLoading', false);
        });

        // Playback events
        this.player.on('play', () => {
            AppState.set('streamStatus.isPlaying', true);
        });

        this.player.on('pause', () => {
            AppState.set('streamStatus.isPlaying', false);
        });

        this.player.on('ended', () => {
            AppState.set('streamStatus.isPlaying', false);
        });
    }

    /**
     * Load a stream URL
     * @param {string} url - Stream URL
     * @param {string} title - Stream title
     * @returns {Promise}
     */
    async loadStream(url, title = '') {
        if (!this.player) {
            throw new Error('Player not initialized');
        }

        try {
            // Validate URL
            if (!InputValidator.validateStreamUrl(url)) {
                throw new Error('Invalid stream URL format');
            }

            // Clean up previous stream
            await this.cleanup();

            // Store current stream info
            this.currentStream = url;
            
            // Update state
            if (!this.isDedicated) {
                AppState.set('streamStatus.currentStream', url);
                AppState.set('streamStatus.currentTitle', title || this.truncateUrl(url));
            }

            // Check if it's an HLS stream
            const isHLS = this.isHLSStream(url);

            if (isHLS) {
                await this.loadHLSStream(url);
            } else {
                await this.loadDirectStream(url);
            }

            this.showNotification(`Loaded: ${title || 'Stream'}`, 'success');
            
            return { success: true };
        } catch (error) {
            const errorMessage = ErrorHandler.handleStreamError(error, url);
            this.showNotification(errorMessage, 'error');
            
            return { success: false, error: errorMessage };
        }
    }

    /**
     * Load HLS stream using hls.js
     * @param {string} url - HLS stream URL
     */
    async loadHLSStream(url) {
        if (!window.Hls) {
            throw new Error('HLS.js library not available');
        }

        if (Hls.isSupported()) {
            this.hls = new Hls({
                enableWorker: true,
                lowLatencyMode: true,
                backBufferLength: 90
            });

            // Set up HLS event listeners
            this.setupHLSEventListeners();

            // Load source and attach to video element
            this.hls.loadSource(url);
            this.hls.attachMedia(this.player.el().querySelector('video'));

            // Wait for manifest to be parsed
            await new Promise((resolve, reject) => {
                this.hls.on(Hls.Events.MANIFEST_PARSED, resolve);
                this.hls.on(Hls.Events.ERROR, (event, data) => {
                    if (data.fatal) reject(new Error(data.details));
                });
            });

            // Start playback
            if (this.options.autoplay) {
                await this.player.play();
            }
        } else if (this.player.el().querySelector('video').canPlayType('application/vnd.apple.mpegurl')) {
            // Native HLS support (Safari)
            this.player.src({ src: url, type: 'application/x-mpegURL' });
            this.player.load();
            
            if (this.options.autoplay) {
                await this.player.play();
            }
        } else {
            throw new Error('HLS not supported on this browser');
        }
    }

    /**
     * Load direct video stream
     * @param {string} url - Video URL
     */
    async loadDirectStream(url) {
        const mimeType = this.getMimeType(url);
        
        this.player.src({ src: url, type: mimeType });
        this.player.load();
        
        if (this.options.autoplay) {
            await this.player.play();
        }
    }

    /**
     * Set up HLS-specific event listeners
     */
    setupHLSEventListeners() {
        if (!this.hls) return;

        this.hls.on(Hls.Events.ERROR, (event, data) => {
            console.error('HLS Error:', data);
            
            if (data.fatal) {
                switch (data.type) {
                    case Hls.ErrorTypes.NETWORK_ERROR:
                        // Try to recover network error
                        console.log('Trying to recover from network error');
                        this.hls.startLoad();
                        break;
                    case Hls.ErrorTypes.MEDIA_ERROR:
                        // Try to recover media error
                        console.log('Trying to recover from media error');
                        this.hls.recoverMediaError();
                        break;
                    default:
                        // Cannot recover
                        this.showNotification(ErrorHandler.handleStreamError(new Error(data.details)), 'error');
                        break;
                }
            }
        });

        this.hls.on(Hls.Events.MANIFEST_LOADED, (event, data) => {
            console.log('HLS manifest loaded:', data.url);
        });
    }

    /**
     * Load local file
     * @param {File} file - File object
     * @returns {Promise}
     */
    async loadLocalFile(file) {
        const validation = InputValidator.validateFile(file);
        if (!validation.valid) {
            throw new Error(validation.error);
        }

        const fileURL = URL.createObjectURL(file);
        
        try {
            const result = await this.loadStream(fileURL, file.name);
            
            // Clean up object URL when player is disposed
            this.player.one('dispose', () => {
                URL.revokeObjectURL(fileURL);
            });
            
            return result;
        } catch (error) {
            URL.revokeObjectURL(fileURL);
            throw error;
        }
    }

    /**
     * Apply picture settings (CSS filters)
     * @param {object} settings - Picture settings
     */
    applyPictureSettings(settings) {
        if (!this.player) return;

        const { brightness, contrast, saturation } = settings;
        const videoElement = this.player.el().querySelector('video');
        
        if (videoElement) {
            const filterStyle = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;
            videoElement.style.filter = filterStyle;
        }
    }

    /**
     * Clean up resources
     */
    async cleanup() {
        if (this.hls) {
            this.hls.destroy();
            this.hls = null;
        }
        
        if (this.player) {
            this.player.pause();
        }
    }

    /**
     * Dispose of the player
     */
    dispose() {
        this.cleanup();
        
        if (this.player) {
            this.player.dispose();
            this.player = null;
        }
    }

    /**
     * Check if URL is an HLS stream
     * @param {string} url - URL to check
     * @returns {boolean}
     */
    isHLSStream(url) {
        return url.toLowerCase().includes('.m3u8');
    }

    /**
     * Get MIME type from URL
     * @param {string} url - Video URL
     * @returns {string}
     */
    getMimeType(url) {
        const extension = url.split('.').pop().toLowerCase();
        const mimeTypes = {
            'mp4': 'video/mp4',
            'webm': 'video/webm',
            'ogg': 'video/ogg',
            'mov': 'video/mp4',
            'avi': 'video/mp4',
            'm3u8': 'application/x-mpegURL'
        };
        
        return mimeTypes[extension] || 'video/mp4';
    }

    /**
     * Truncate URL for display
     * @param {string} url - URL to truncate
     * @returns {string}
     */
    truncateUrl(url) {
        return url.length > 50 ? url.substring(0, 50) + '...' : url;
    }

    /**
     * Show notification
     * @param {string} message - Notification message
     * @param {string} type - Notification type
     */
    showNotification(message, type = 'info') {
        // This would typically dispatch to a notification system
        // For now, we'll use the existing showMessage function if available
        if (window.showMessage) {
            window.showMessage(message, type === 'error');
        } else {
            console.log(`${type.toUpperCase()}: ${message}`);
        }
    }
}

export default VideoPlayer;
