/**
 * Input validation and sanitization utilities
 */
class InputValidator {
    /**
     * Validates if a string is a valid URL
     * @param {string} url - URL to validate
     * @returns {boolean}
     */
    static validateUrl(url) {
        if (!url || typeof url !== 'string') return false;
        
        try {
            const urlObj = new URL(url);
            const allowedProtocols = ['http:', 'https:'];
            return allowedProtocols.includes(urlObj.protocol);
        } catch {
            return false;
        }
    }

    /**
     * Validates stream URL with allowed extensions
     * @param {string} url - Stream URL to validate
     * @returns {boolean}
     */
    static validateStreamUrl(url) {
        if (!this.validateUrl(url)) return false;
        
        const allowedExtensions = ['.mp4', '.mov', '.m3u8', '.webm', '.avi', '.mkv'];
        const urlLower = url.toLowerCase();
        
        return allowedExtensions.some(ext => urlLower.includes(ext)) || 
               urlLower.includes('stream') || 
               urlLower.includes('video');
    }

    /**
     * Sanitizes text content to prevent XSS
     * @param {string} text - Text to sanitize
     * @returns {string}
     */
    static sanitizeText(text) {
        if (!text || typeof text !== 'string') return '';
        
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Sanitizes HTML content
     * @param {string} html - HTML to sanitize
     * @returns {string}
     */
    static sanitizeHtml(html) {
        if (!html || typeof html !== 'string') return '';
        
        // Basic HTML sanitization - in production, use DOMPurify
        return html
            .replace(/<script[^>]*>.*?<\/script>/gi, '')
            .replace(/<iframe[^>]*>.*?<\/iframe>/gi, '')
            .replace(/javascript:/gi, '')
            .replace(/on\w+\s*=/gi, '')
            .replace(/<object[^>]*>.*?<\/object>/gi, '')
            .replace(/<embed[^>]*>/gi, '')
            .replace(/<form[^>]*>.*?<\/form>/gi, '');
    }

    /**
     * Validates file input
     * @param {File} file - File object to validate
     * @returns {object}
     */
    static validateFile(file) {
        const maxSize = 500 * 1024 * 1024; // 500MB
        const allowedTypes = [
            'video/mp4', 'video/webm', 'video/ogg', 'video/avi',
            'video/mov', 'video/wmv', 'video/flv', 'video/mkv'
        ];

        if (!file) {
            return { valid: false, error: 'No file provided' };
        }

        if (file.size > maxSize) {
            return { valid: false, error: 'File size exceeds 500MB limit' };
        }

        if (!allowedTypes.includes(file.type)) {
            return { valid: false, error: 'File type not supported' };
        }

        return { valid: true };
    }

    /**
     * Validates chat input
     * @param {string} message - Chat message to validate
     * @returns {object}
     */
    static validateChatInput(message) {
        if (!message || typeof message !== 'string') {
            return { valid: false, error: 'Message is required' };
        }

        const trimmed = message.trim();
        if (trimmed.length === 0) {
            return { valid: false, error: 'Message cannot be empty' };
        }

        if (trimmed.length > 1000) {
            return { valid: false, error: 'Message too long (max 1000 characters)' };
        }

        // Check for potential spam patterns
        const spamPatterns = [
            /\b(?:https?:\/\/)?(?:www\.)?[a-z0-9]+\.[a-z]{2,}(?:\/\S*)?\b/gi,
            /\b[A-Z]{5,}\b/g,
            /(.)\1{4,}/g
        ];

        for (const pattern of spamPatterns) {
            if (pattern.test(trimmed)) {
                return { valid: false, error: 'Message contains suspicious content' };
            }
        }

        return { valid: true, sanitized: this.sanitizeText(trimmed) };
    }
}

export default InputValidator;
