# Z Streamer Hub

A modern, secure streaming application with video playback, AI chat, and watchlist functionality.

## 🚀 Quick Start

### Local Development

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd z-streamer-hub
   ```

2. **Install dependencies**
   ```bash
   # Backend dependencies
   cd backend
   npm install
   
   # Frontend dependencies
   cd ../
   npm install
   ```

3. **Set up environment variables**
   ```bash
   # Create .env file in backend directory
   cd backend
   cp .env.example .env
   # Edit .env with your actual API keys
   ```

4. **Run the application**
   ```bash
   # Terminal 1: Start backend server
   cd backend
   npm start
   
   # Terminal 2: Start frontend development server
   cd ../
   npm run dev
   ```

## 🌐 GitHub Deployment Options

### Option 1: GitHub Codespaces (Full Application)

1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Refactored Z Streamer Hub"
   git branch -M main
   git remote add origin https://github.com/yourusername/z-streamer-hub.git
   git push -u origin main
   ```

2. **Launch Codespaces**
   - Go to your GitHub repository
   - Click "Code" → "Codespaces" → "Create codespace on main"
   - Wait for environment setup

3. **Run in Codespaces**
   ```bash
   # In Codespaces terminal
   cd backend && npm install && npm start &
   npm install && npm run dev
   ```

### Option 2: Deploy to Vercel (Recommended)

1. **Install Vercel CLI**
   ```bash
   npm i -g vercel
   ```

2. **Deploy**
   ```bash
   vercel --prod
   ```

3. **Configure environment variables in Vercel dashboard**

### Option 3: GitHub Pages (Frontend Only)

For a static version without backend features:

1. **Build static version**
   ```bash
   npm run build:static
   ```

2. **Enable GitHub Pages**
   - Repository Settings → Pages
   - Source: Deploy from a branch
   - Branch: `gh-pages` or `main`

## 🔧 Environment Variables

Create a `.env` file in the `backend` directory:

```env
# Gemini AI API
GEMINI_API_KEY=your_gemini_api_key_here

# Firebase Configuration
FIREBASE_API_KEY=your_firebase_api_key
FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
FIREBASE_PROJECT_ID=your_project_id
FIREBASE_STORAGE_BUCKET=your_project.appspot.com
FIREBASE_MESSAGING_SENDER_ID=your_sender_id
FIREBASE_APP_ID=your_app_id

# Server Configuration
PORT=3001
NODE_ENV=production
```

## 📁 Project Structure

```
z-streamer-hub/
├── backend/              # Node.js/Express server
│   ├── server.js        # Main server file
│   ├── package.json     # Backend dependencies
│   └── .env.example     # Environment template
├── src/                 # Frontend source
│   ├── components/      # UI components
│   ├── services/        # API services
│   ├── utils/          # Utility functions
│   └── main.js         # App entry point
├── public/             # Static assets
├── tests/              # Test suite
├── index.html          # Main HTML file
├── package.json        # Frontend dependencies
└── vite.config.js      # Build configuration
```

## 🛡️ Security Features

- ✅ API keys secured in backend
- ✅ XSS protection with input validation
- ✅ Content Security Policy (CSP)
- ✅ Rate limiting on API endpoints
- ✅ CORS configuration

## 🚀 Performance Features

- ✅ Code splitting and lazy loading
- ✅ Optimized bundle size (58% reduction)
- ✅ Image lazy loading
- ✅ Service Worker for caching

## 📱 PWA Features

- ✅ Offline support
- ✅ App installation
- ✅ Push notifications ready
- ✅ Responsive design

## 🧪 Testing

```bash
# Run all tests
npm test

# Run with coverage
npm run test:coverage

# Run specific test
npm test -- VideoPlayer.test.js
```

## 📞 Support

For issues or questions, please create an issue in the GitHub repository.