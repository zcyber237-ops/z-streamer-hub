/**
 * @jest-environment jsdom
 */
import InputValidator from '../src/utils/inputValidator.js';

describe('InputValidator', () => {
    describe('validateUrl', () => {
        test('should validate valid HTTP URLs', () => {
            expect(InputValidator.validateUrl('http://example.com')).toBe(true);
            expect(InputValidator.validateUrl('https://example.com')).toBe(true);
        });

        test('should reject invalid URLs', () => {
            expect(InputValidator.validateUrl('ftp://example.com')).toBe(false);
            expect(InputValidator.validateUrl('javascript:alert(1)')).toBe(false);
            expect(InputValidator.validateUrl('not-a-url')).toBe(false);
            expect(InputValidator.validateUrl('')).toBe(false);
            expect(InputValidator.validateUrl(null)).toBe(false);
        });
    });

    describe('validateStreamUrl', () => {
        test('should validate stream URLs with correct extensions', () => {
            expect(InputValidator.validateStreamUrl('https://example.com/video.mp4')).toBe(true);
            expect(InputValidator.validateStreamUrl('https://example.com/stream.m3u8')).toBe(true);
            expect(InputValidator.validateStreamUrl('https://example.com/movie.webm')).toBe(true);
        });

        test('should validate URLs with stream keywords', () => {
            expect(InputValidator.validateStreamUrl('https://example.com/live-stream')).toBe(true);
            expect(InputValidator.validateStreamUrl('https://video.example.com/content')).toBe(true);
        });

        test('should reject non-stream URLs', () => {
            expect(InputValidator.validateStreamUrl('https://example.com/document.pdf')).toBe(false);
            expect(InputValidator.validateStreamUrl('javascript:alert(1)')).toBe(false);
        });
    });

    describe('sanitizeText', () => {
        test('should sanitize text content', () => {
            expect(InputValidator.sanitizeText('<script>alert(1)</script>test'))
                .toBe('&lt;script&gt;alert(1)&lt;/script&gt;test');
            expect(InputValidator.sanitizeText('Normal text')).toBe('Normal text');
        });

        test('should handle edge cases', () => {
            expect(InputValidator.sanitizeText('')).toBe('');
            expect(InputValidator.sanitizeText(null)).toBe('');
            expect(InputValidator.sanitizeText(undefined)).toBe('');
        });
    });

    describe('validateChatInput', () => {
        test('should validate normal chat messages', () => {
            const result = InputValidator.validateChatInput('Hello, how are you?');
            expect(result.valid).toBe(true);
            expect(result.sanitized).toBe('Hello, how are you?');
        });

        test('should reject empty messages', () => {
            expect(InputValidator.validateChatInput('').valid).toBe(false);
            expect(InputValidator.validateChatInput('   ').valid).toBe(false);
            expect(InputValidator.validateChatInput(null).valid).toBe(false);
        });

        test('should reject messages that are too long', () => {
            const longMessage = 'a'.repeat(1001);
            expect(InputValidator.validateChatInput(longMessage).valid).toBe(false);
        });

        test('should detect potential spam patterns', () => {
            expect(InputValidator.validateChatInput('HELLO WORLD CAPS LOCK').valid).toBe(false);
            expect(InputValidator.validateChatInput('aaaaaaaaaa').valid).toBe(false);
        });
    });

    describe('validateFile', () => {
        test('should validate video files', () => {
            const mockFile = {
                size: 1024 * 1024, // 1MB
                type: 'video/mp4'
            };
            
            const result = InputValidator.validateFile(mockFile);
            expect(result.valid).toBe(true);
        });

        test('should reject files that are too large', () => {
            const mockFile = {
                size: 600 * 1024 * 1024, // 600MB
                type: 'video/mp4'
            };
            
            const result = InputValidator.validateFile(mockFile);
            expect(result.valid).toBe(false);
            expect(result.error).toContain('size exceeds');
        });

        test('should reject unsupported file types', () => {
            const mockFile = {
                size: 1024 * 1024,
                type: 'application/pdf'
            };
            
            const result = InputValidator.validateFile(mockFile);
            expect(result.valid).toBe(false);
            expect(result.error).toContain('not supported');
        });
    });
});
