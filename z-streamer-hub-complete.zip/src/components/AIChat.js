import AppState from '../state/appState.js';
import ApiService from '../services/apiService.js';
import InputValidator from '../utils/inputValidator.js';

/**
 * AI Chat Component for user assistance
 */
class AIChat {
    constructor(containerId) {
        this.containerId = containerId;
        this.container = document.getElementById(containerId);
        
        if (!this.container) {
            throw new Error(`AI Chat container ${containerId} not found`);
        }
        
        this.chatLog = null;
        this.chatInput = null;
        this.sendButton = null;
        
        this.initialize();
    }

    /**
     * Initialize the AI chat component
     */
    initialize() {
        this.render();
        this.setupEventListeners();
        this.displayWelcomeMessage();
    }

    /**
     * Render the chat interface
     */
    render() {
        this.container.innerHTML = `
            <div class="p-6 rounded-xl card-bg shadow-2xl">
                <div id="${this.containerId}-log" class="bg-gray-800 p-4 rounded-lg h-96 overflow-y-auto space-y-4 mb-4 custom-scrollbar"></div>
                <div class="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
                    <input 
                        type="text" 
                        id="${this.containerId}-input" 
                        placeholder="Ask the AI Engineer a question..." 
                        class="w-full p-3 rounded-lg bg-gray-700 text-white border border-gray-600 focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                        maxlength="1000"
                        autocomplete="off"
                    >
                    <button 
                        id="${this.containerId}-send"
                        class="bg-yellow-600 text-white font-semibold py-3 px-6 rounded-lg hover:bg-yellow-500 whitespace-nowrap transition duration-150 disabled:opacity-50 disabled:cursor-not-allowed"
                        aria-label="Send message"
                    >
                        <span class="button-text">Ask</span>
                        <svg class="animate-spin h-5 w-5 text-white hidden" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    </button>
                </div>
            </div>
        `;
        
        // Get references to elements
        this.chatLog = document.getElementById(`${this.containerId}-log`);
        this.chatInput = document.getElementById(`${this.containerId}-input`);
        this.sendButton = document.getElementById(`${this.containerId}-send`);
    }

    /**
     * Set up event listeners
     */
    setupEventListeners() {
        // Send button click
        this.sendButton.addEventListener('click', () => {
            this.handleSendMessage();
        });
        
        // Enter key press
        this.chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                this.handleSendMessage();
            }
        });
        
        // Input validation
        this.chatInput.addEventListener('input', (e) => {
            const isValid = e.target.value.trim().length > 0;
            this.sendButton.disabled = !isValid;
        });
    }

    /**
     * Display welcome message
     */
    displayWelcomeMessage() {
        this.displayMessage('AI', {
            type: 'welcome',
            content: 'Hello! I can help you diagnose stream errors (e.g., **manifestLoadError**) and provide general streaming knowledge. Ask me a question!'
        });
    }

    /**
     * Handle send message action
     */
    async handleSendMessage() {
        const message = this.chatInput.value.trim();
        
        if (!message) {
            return;
        }
        
        // Validate input
        const validation = InputValidator.validateChatInput(message);
        if (!validation.valid) {
            this.showNotification(validation.error, 'error');
            return;
        }
        
        // Display user message
        this.displayMessage('User', { content: validation.sanitized });
        
        // Clear input and show loading
        this.chatInput.value = '';
        this.setLoadingState(true);
        
        try {
            // Send to AI service via secure backend
            const response = await ApiService.sendChatMessage(validation.sanitized);
            
            // Display AI response
            this.displayMessage('AI', {
                content: response.message || response.text || 'Sorry, I couldn\'t generate a response.',
                sources: response.sources
            });
            
        } catch (error) {
            console.error('AI Chat Error:', error);
            this.displayMessage('AI', {
                type: 'error',
                content: `Service temporarily unavailable: ${error.message}. Please try again later.`
            });
        } finally {
            this.setLoadingState(false);
            this.chatInput.focus();
        }
    }

    /**
     * Display a message in the chat log
     * @param {string} sender - 'User' or 'AI'
     * @param {object} messageData - Message data
     */
    displayMessage(sender, messageData) {
        const { content, type = 'normal', sources } = messageData;
        
        const messageDiv = document.createElement('div');
        const isUser = sender === 'User';
        const isError = type === 'error';
        const isWelcome = type === 'welcome';
        
        messageDiv.className = `flex items-start space-x-3 ${isUser ? 'justify-end' : 'justify-start'}`;
        
        const avatarClass = isUser ? 'bg-gray-500' : (isError ? 'bg-red-600' : 'netflix-red');
        const bubbleClass = isUser ? 'bg-gray-600' : (isError ? 'bg-red-800' : 'bg-gray-700');
        const textClass = isUser ? 'text-white' : (isError ? 'text-red-200' : 'text-gray-200');
        const nameClass = isUser ? 'text-blue-300' : (isWelcome ? 'text-yellow-300' : 'text-yellow-300');
        const borderClass = isUser ? 'rounded-tr-none' : 'rounded-tl-none';
        
        const senderName = isUser ? 'You' : 'Media Engineer';
        const avatarText = isUser ? 'U' : 'AI';
        
        // Sanitize content
        const sanitizedContent = InputValidator.sanitizeHtml(content);
        
        // Create sources section if available
        let sourcesHtml = '';
        if (sources && sources.length > 0) {
            sourcesHtml = `
                <div class="mt-2 p-2 bg-gray-600 rounded text-xs">
                    <strong>Sources:</strong>
                    <ul class="mt-1 list-disc list-inside">
                        ${sources.map(source => `<li><a href="${source.url}" target="_blank" class="text-blue-300 hover:underline">${InputValidator.sanitizeText(source.title)}</a></li>`).join('')}
                    </ul>
                </div>
            `;
        }
        
        messageDiv.innerHTML = `
            ${!isUser ? `<div class="w-8 h-8 rounded-full ${avatarClass} flex items-center justify-center font-bold text-white text-xs flex-shrink-0">${avatarText}</div>` : ''}
            <div class="${bubbleClass} p-3 rounded-xl ${borderClass} max-w-lg">
                <p class="font-bold ${nameClass}">${senderName}</p>
                <div class="text-sm ${textClass}">${sanitizedContent}</div>
                ${sourcesHtml}
            </div>
            ${isUser ? `<div class="w-8 h-8 rounded-full ${avatarClass} flex items-center justify-center font-bold text-white text-xs flex-shrink-0">${avatarText}</div>` : ''}
        `;
        
        this.chatLog.appendChild(messageDiv);
        this.scrollToBottom();
    }

    /**
     * Set loading state for the chat
     * @param {boolean} isLoading - Loading state
     */
    setLoadingState(isLoading) {
        const buttonText = this.sendButton.querySelector('.button-text');
        const spinner = this.sendButton.querySelector('svg');
        
        if (isLoading) {
            this.sendButton.disabled = true;
            buttonText.textContent = 'Thinking...';
            spinner.classList.remove('hidden');
            this.chatInput.disabled = true;
        } else {
            this.sendButton.disabled = false;
            buttonText.textContent = 'Ask';
            spinner.classList.add('hidden');
            this.chatInput.disabled = false;
        }
    }

    /**
     * Scroll chat log to bottom
     */
    scrollToBottom() {
        this.chatLog.scrollTop = this.chatLog.scrollHeight;
    }

    /**
     * Show notification
     * @param {string} message - Message to show
     * @param {string} type - Notification type
     */
    showNotification(message, type = 'info') {
        if (window.showMessage) {
            window.showMessage(message, type === 'error');
        } else {
            console.log(`${type.toUpperCase()}: ${message}`);
        }
    }

    /**
     * Clear chat log
     */
    clearChat() {
        this.chatLog.innerHTML = '';
        this.displayWelcomeMessage();
    }
}

export default AIChat;
