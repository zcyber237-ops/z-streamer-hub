import AppState from '../state/appState.js';
import ApiService from '../services/apiService.js';
import InputValidator from '../utils/inputValidator.js';

/**
 * Watchlist Component for managing saved streams
 */
class Watchlist {
    constructor(containerId) {
        this.containerId = containerId;
        this.container = document.getElementById(containerId);
        
        if (!this.container) {
            throw new Error(`Watchlist container ${containerId} not found`);
        }
        
        this.initialize();
    }

    /**
     * Initialize the watchlist component
     */
    initialize() {
        // Subscribe to watchlist changes
        AppState.subscribe('watchlist', (watchlist) => {
            this.render(watchlist);
        });
        
        // Initial render
        const watchlist = AppState.get('watchlist');
        this.render(watchlist);
    }

    /**
     * Render the watchlist
     * @param {Map} watchlist - Watchlist items
     */
    render(watchlist) {
        this.container.innerHTML = '';
        
        if (!watchlist || watchlist.size === 0) {
            this.renderEmptyState();
            return;
        }
        
        const items = Array.from(watchlist.values());
        const grid = this.createGrid();
        
        items.forEach(item => {
            const card = this.createWatchlistCard(item);
            grid.appendChild(card);
        });
        
        this.container.appendChild(grid);
    }

    /**
     * Render empty state
     */
    renderEmptyState() {
        const emptyState = document.createElement('div');
        emptyState.className = 'col-span-full text-center text-gray-400 pt-10';
        emptyState.innerHTML = `
            <div class="max-w-md mx-auto">
                <svg class="mx-auto h-16 w-16 text-gray-500 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 4V2a1 1 0 011-1h8a1 1 0 011 1v2m-9 7h10m-5-5v10" />
                </svg>
                <h3 class="text-lg font-medium mb-2">Your list is empty</h3>
                <p class="text-sm">Add items from the Dashboard to build your personal collection!</p>
            </div>
        `;
        
        this.container.appendChild(emptyState);
    }

    /**
     * Create grid container
     * @returns {HTMLElement}
     */
    createGrid() {
        const grid = document.createElement('div');
        grid.className = 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 p-4 rounded-xl card-bg shadow-2xl min-h-60';
        return grid;
    }

    /**
     * Create watchlist card
     * @param {object} item - Watchlist item
     * @returns {HTMLElement}
     */
    createWatchlistCard(item) {
        const card = document.createElement('div');
        card.className = 'stream-card bg-cardBg rounded-lg overflow-hidden shadow-lg transform hover:scale-105 transition duration-300';
        
        // Sanitize item data
        const sanitizedTitle = InputValidator.sanitizeText(item.title);
        const sanitizedDescription = InputValidator.sanitizeText(item.description || 'No description available');
        
        card.innerHTML = `
            <div class="relative">
                <img 
                    src="${item.poster}" 
                    alt="${sanitizedTitle}"
                    class="w-full h-auto object-cover"
                    loading="lazy"
                />
                <div class="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center opacity-0 hover:opacity-100 transition duration-300">
                    <button 
                        class="play-button bg-white text-black font-bold py-2 px-4 rounded-full shadow-lg flex items-center space-x-2"
                        aria-label="Play ${sanitizedTitle}"
                        data-stream-id="${item.id}"
                        data-stream-title="${sanitizedTitle}"
                        data-stream-url="${item.url}"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clip-rule="evenodd" />
                        </svg>
                        <span>Play</span>
                    </button>
                </div>
            </div>
            <div class="p-4">
                <h4 class="text-lg font-semibold truncate text-white mb-2" title="${sanitizedTitle}">${sanitizedTitle}</h4>
                <p class="text-xs text-gray-400 mb-3">${sanitizedDescription}</p>
                <button 
                    class="remove-button w-full text-sm font-semibold py-2 px-4 rounded transition duration-150 bg-red-700 hover:bg-red-600"
                    data-stream-id="${item.id}"
                    aria-label="Remove ${sanitizedTitle} from watchlist"
                >
                    ✓ Remove from List
                </button>
            </div>
        `;
        
        // Add event listeners
        this.attachCardEventListeners(card, item);
        
        return card;
    }

    /**
     * Attach event listeners to card elements
     * @param {HTMLElement} card - Card element
     * @param {object} item - Stream item
     */
    attachCardEventListeners(card, item) {
        // Play button
        const playButton = card.querySelector('.play-button');
        if (playButton) {
            playButton.addEventListener('click', (e) => {
                e.preventDefault();
                this.handlePlayStream(item);
            });
        }
        
        // Remove button
        const removeButton = card.querySelector('.remove-button');
        if (removeButton) {
            removeButton.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleRemoveFromWatchlist(item);
            });
        }
    }

    /**
     * Handle play stream action
     * @param {object} item - Stream item
     */
    handlePlayStream(item) {
        if (!InputValidator.validateStreamUrl(item.url)) {
            this.showNotification('Invalid stream URL', 'error');
            return;
        }
        
        const event = new CustomEvent('watchlist:play-stream', {
            detail: {
                id: item.id,
                title: item.title,
                url: item.url
            }
        });
        
        document.dispatchEvent(event);
    }

    /**
     * Handle remove from watchlist
     * @param {object} item - Stream item
     */
    handleRemoveFromWatchlist(item) {
        const event = new CustomEvent('watchlist:remove-item', {
            detail: { itemId: item.id }
        });
        
        document.dispatchEvent(event);
    }

    /**
     * Show notification
     * @param {string} message - Message to show
     * @param {string} type - Notification type
     */
    showNotification(message, type = 'info') {
        if (window.showMessage) {
            window.showMessage(message, type === 'error');
        } else {
            console.log(`${type.toUpperCase()}: ${message}`);
        }
    }
}

export default Watchlist;
