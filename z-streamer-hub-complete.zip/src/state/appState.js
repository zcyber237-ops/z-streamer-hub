/**
 * Centralized state management for the application
 */
class AppState {
    constructor() {
        this.state = {
            user: null,
            watchlist: new Map(),
            activeRegion: 'USA',
            isVpnOn: false,
            pictureSettings: {
                brightness: 100,
                contrast: 100,
                saturation: 100
            },
            currentView: 'dashboard',
            streamStatus: {
                isPlaying: false,
                currentStream: null,
                currentTitle: 'Select a stream or load a file'
            },
            ui: {
                isLoading: false,
                notifications: [],
                errors: []
            }
        };
        
        this.subscribers = new Map();
        this.middleware = [];
    }

    /**
     * Subscribe to state changes
     * @param {string} key - State key to watch
     * @param {Function} callback - Callback function
     * @returns {Function} Unsubscribe function
     */
    subscribe(key, callback) {
        if (!this.subscribers.has(key)) {
            this.subscribers.set(key, new Set());
        }
        
        this.subscribers.get(key).add(callback);
        
        // Return unsubscribe function
        return () => {
            const subscribers = this.subscribers.get(key);
            if (subscribers) {
                subscribers.delete(callback);
            }
        };
    }

    /**
     * Add middleware for state changes
     * @param {Function} middleware - Middleware function
     */
    addMiddleware(middleware) {
        this.middleware.push(middleware);
    }

    /**
     * Get current state value
     * @param {string} key - State key
     * @returns {any} State value
     */
    get(key) {
        const keys = key.split('.');
        let value = this.state;
        
        for (const k of keys) {
            value = value?.[k];
            if (value === undefined) break;
        }
        
        return value;
    }

    /**
     * Set state value and notify subscribers
     * @param {string} key - State key
     * @param {any} value - New value
     * @param {object} meta - Additional metadata
     */
    set(key, value, meta = {}) {
        const oldValue = this.get(key);
        
        // Run middleware
        for (const middleware of this.middleware) {
            const result = middleware(key, value, oldValue, meta);
            if (result === false) {
                console.warn(`State change blocked by middleware for key: ${key}`);
                return;
            }
        }
        
        // Set the value
        this.setDeep(key, value);
        
        // Notify subscribers
        this.notify(key, value, oldValue, meta);
        
        // Save to localStorage if needed
        this.persistState(key, value);
    }

    /**
     * Set nested state value
     * @param {string} key - Dot-notation key
     * @param {any} value - Value to set
     */
    setDeep(key, value) {
        const keys = key.split('.');
        let current = this.state;
        
        for (let i = 0; i < keys.length - 1; i++) {
            const k = keys[i];
            if (!(k in current) || typeof current[k] !== 'object') {
                current[k] = {};
            }
            current = current[k];
        }
        
        current[keys[keys.length - 1]] = value;
    }

    /**
     * Notify subscribers of state changes
     * @param {string} key - State key
     * @param {any} newValue - New value
     * @param {any} oldValue - Previous value
     * @param {object} meta - Additional metadata
     */
    notify(key, newValue, oldValue, meta) {
        // Notify exact key subscribers
        const exactSubscribers = this.subscribers.get(key);
        if (exactSubscribers) {
            exactSubscribers.forEach(callback => {
                try {
                    callback(newValue, oldValue, meta);
                } catch (error) {
                    console.error(`Error in state subscriber for ${key}:`, error);
                }
            });
        }
        
        // Notify wildcard subscribers (e.g., '*' or 'user.*')
        this.subscribers.forEach((subscribers, subscriberKey) => {
            if (subscriberKey.includes('*')) {
                const pattern = subscriberKey.replace(/\*/g, '.*');
                const regex = new RegExp(`^${pattern}$`);
                if (regex.test(key)) {
                    subscribers.forEach(callback => {
                        try {
                            callback(newValue, oldValue, meta);
                        } catch (error) {
                            console.error(`Error in wildcard state subscriber for ${subscriberKey}:`, error);
                        }
                    });
                }
            }
        });
    }

    /**
     * Update state using a function
     * @param {string} key - State key
     * @param {Function} updater - Function that receives current value and returns new value
     * @param {object} meta - Additional metadata
     */
    update(key, updater, meta = {}) {
        const currentValue = this.get(key);
        const newValue = updater(currentValue);
        this.set(key, newValue, meta);
    }

    /**
     * Reset state to initial values
     */
    reset() {
        const initialState = {
            user: null,
            watchlist: new Map(),
            activeRegion: 'USA',
            isVpnOn: false,
            pictureSettings: {
                brightness: 100,
                contrast: 100,
                saturation: 100
            },
            currentView: 'dashboard',
            streamStatus: {
                isPlaying: false,
                currentStream: null,
                currentTitle: 'Select a stream or load a file'
            },
            ui: {
                isLoading: false,
                notifications: [],
                errors: []
            }
        };
        
        this.state = initialState;
        this.notify('*', this.state, {}, { type: 'reset' });
    }

    /**
     * Persist certain state values to localStorage
     * @param {string} key - State key
     * @param {any} value - Value to persist
     */
    persistState(key, value) {
        const persistKeys = ['activeRegion', 'pictureSettings', 'isVpnOn'];
        
        if (persistKeys.includes(key)) {
            try {
                localStorage.setItem(`streamhub_${key}`, JSON.stringify(value));
            } catch (error) {
                console.warn('Failed to persist state to localStorage:', error);
            }
        }
    }

    /**
     * Load persisted state from localStorage
     */
    loadPersistedState() {
        const persistKeys = ['activeRegion', 'pictureSettings', 'isVpnOn'];
        
        persistKeys.forEach(key => {
            try {
                const stored = localStorage.getItem(`streamhub_${key}`);
                if (stored) {
                    const value = JSON.parse(stored);
                    this.set(key, value, { type: 'loaded' });
                }
            } catch (error) {
                console.warn(`Failed to load persisted state for ${key}:`, error);
            }
        });
    }

    /**
     * Get entire state (for debugging)
     * @returns {object} Current state
     */
    getState() {
        return { ...this.state };
    }
}

export default new AppState();
