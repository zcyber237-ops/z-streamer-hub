import EnvironmentConfig from './config/environment.js';
import AppState from './state/appState.js';
import ErrorHandler from './utils/errorHandler.js';
import InputValidator from './utils/inputValidator.js';
import ApiService from './services/apiService.js';
import VideoPlayer from './components/VideoPlayer.js';
import Dashboard from './components/Dashboard.js';
import Watchlist from './components/Watchlist.js';
import AIChat from './components/AIChat.js';

/**
 * Main Application Class - Orchestrates all components
 */
class StreamHubApp {
    constructor() {
        this.components = {};
        this.currentView = 'dashboard';
        
        this.initialize();
    }

    /**
     * Initialize the application
     */
    async initialize() {
        try {
            // Load persisted state
            AppState.loadPersistedState();
            
            // Set up global error handling
            this.setupGlobalErrorHandling();
            
            // Initialize components when DOM is ready
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => this.initializeComponents());
            } else {
                await this.initializeComponents();
            }
            
            // Set up navigation
            this.setupNavigation();
            
            // Set up global event listeners
            this.setupGlobalEventListeners();
            
            // Initialize Firebase (if available)
            await this.initializeFirebase();
            
            // Register service worker for PWA
            this.registerServiceWorker();
            
            console.log('StreamHub App initialized successfully');
            
        } catch (error) {
            console.error('Failed to initialize app:', error);
            this.showNotification('Failed to initialize application', 'error');
        }
    }

    /**
     * Initialize all components
     */
    async initializeComponents() {
        try {
            // Initialize main video player (lazy loaded)
            this.components.mainPlayer = new VideoPlayer('main-video-player', {
                autoplay: false
            });
            
            // Initialize dashboard
            this.components.dashboard = new Dashboard('content-rows');
            
            // Initialize watchlist
            this.components.watchlist = new Watchlist('watchlist-container');
            
            // Initialize AI chat (lazy loaded)
            this.loadAIChatComponent();
            
            // Set initial view
            this.changeView('dashboard');
            
        } catch (error) {
            console.error('Failed to initialize components:', error);
            throw error;
        }
    }

    /**
     * Lazy load AI Chat component
     */
    async loadAIChatComponent() {
        // Only load when AI chat view is accessed
        const loadChat = () => {
            if (!this.components.aiChat) {
                this.components.aiChat = new AIChat('ai-chat-container');
            }
        };
        
        // Load on first access to AI chat view
        AppState.subscribe('currentView', (view) => {
            if (view === 'ai-chat') {
                loadChat();
            }
        });
    }

    /**
     * Set up global error handling
     */
    setupGlobalErrorHandling() {
        // Handle unhandled promise rejections
        window.addEventListener('unhandledrejection', (event) => {
            console.error('Unhandled promise rejection:', event.reason);
            ErrorHandler.handleError(event.reason, { type: 'unhandledRejection' });
        });
        
        // Handle JavaScript errors
        window.addEventListener('error', (event) => {
            console.error('JavaScript error:', event.error);
            ErrorHandler.handleError(event.error, {
                type: 'javascript',
                filename: event.filename,
                line: event.lineno
            });
        });
    }

    /**
     * Set up navigation system
     */
    setupNavigation() {
        // Navigation click handlers
        document.addEventListener('click', (e) => {
            const navItem = e.target.closest('[data-nav]');
            if (navItem) {
                e.preventDefault();
                const view = navItem.dataset.nav;
                this.changeView(view);
            }
        });
        
        // Region selector
        const regionSelector = document.getElementById('region-selector');
        if (regionSelector) {
            regionSelector.addEventListener('change', (e) => {
                this.setActiveRegion(e.target.value);
            });
        }
        
        // Region tabs
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('region-tab')) {
                const region = e.target.dataset.region;
                if (region) {
                    this.setActiveRegion(region);
                }
            }
        });
    }

    /**
     * Set up global event listeners
     */
    setupGlobalEventListeners() {
        // Dashboard events
        document.addEventListener('dashboard:play-stream', (e) => {
            const { id, title, url } = e.detail;
            this.playStream(id, title, url);
        });
        
        document.addEventListener('dashboard:watchlist-action', (e) => {
            const { action, item } = e.detail;
            if (action === 'add') {
                this.addToWatchlist(item);
            } else if (action === 'remove') {
                this.removeFromWatchlist(item.id);
            }
        });
        
        // Watchlist events
        document.addEventListener('watchlist:play-stream', (e) => {
            const { id, title, url } = e.detail;
            this.playStream(id, title, url);
        });
        
        document.addEventListener('watchlist:remove-item', (e) => {
            const { itemId } = e.detail;
            this.removeFromWatchlist(itemId);
        });
        
        // VPN toggle
        const vpnStatus = document.getElementById('vpn-status');
        if (vpnStatus) {
            vpnStatus.addEventListener('click', () => {
                this.toggleVPN();
            });
        }
        
        // File input for local files
        const fileInput = document.getElementById('local-file-input');
        if (fileInput) {
            fileInput.addEventListener('change', (e) => {
                this.loadLocalFile(e);
            });
        }
        
        // Custom URL input
        const urlInput = document.getElementById('player-url-input');
        if (urlInput) {
            urlInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.loadCustomStream();
                }
            });
        }
        
        // M3U8 dedicated player
        const m3u8Input = document.getElementById('m3u8-url-input');
        if (m3u8Input) {
            m3u8Input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.loadDedicatedM3U8();
                }
            });
        }
        
        // Picture controls
        this.setupPictureControls();
    }

    /**
     * Set up picture control sliders
     */
    setupPictureControls() {
        const sliders = ['brightness', 'contrast', 'saturation'];
        
        sliders.forEach(type => {
            const slider = document.getElementById(`${type}-slider`);
            const valueDisplay = document.getElementById(`${type}-value`);
            
            if (slider && valueDisplay) {
                slider.addEventListener('input', () => {
                    const value = slider.value;
                    valueDisplay.textContent = `${value}%`;
                    this.updatePictureSettings();
                });
            }
        });
        
        // Reset button
        const resetButton = document.querySelector('[data-action="reset-picture"]');
        if (resetButton) {
            resetButton.addEventListener('click', () => {
                this.resetPictureSettings();
            });
        }
    }

    /**
     * Change the current view
     * @param {string} viewId - View identifier
     */
    changeView(viewId) {
        // Hide all view sections
        document.querySelectorAll('.view-section').forEach(section => {
            section.style.display = 'none';
        });
        
        // Show target view
        const targetView = document.getElementById(`view-${viewId}`);
        if (targetView) {
            targetView.style.display = 'block';
        }
        
        // Update navigation
        document.querySelectorAll('[data-nav]').forEach(nav => {
            nav.classList.remove('active-nav');
        });
        
        const activeNav = document.querySelector(`[data-nav="${viewId}"]`);
        if (activeNav) {
            activeNav.classList.add('active-nav');
        }
        
        // Update state
        AppState.set('currentView', viewId);
        this.currentView = viewId;
        
        // Scroll to top
        window.scrollTo(0, 0);
        
        // Handle view-specific logic
        this.handleViewChange(viewId);
    }

    /**
     * Handle view-specific logic
     * @param {string} viewId - View identifier
     */
    handleViewChange(viewId) {
        switch (viewId) {
            case 'player':
                // Reset picture controls when leaving player
                if (this.currentView !== 'player') {
                    this.resetPictureSettings();
                }
                break;
                
            case 'm3u8-player':
                // Hide dedicated player when leaving M3U8 view
                if (viewId !== 'm3u8-player') {
                    const container = document.getElementById('m3u8-video-container');
                    if (container) {
                        container.classList.add('hidden');
                    }
                }
                break;
        }
    }

    /**
     * Set active region
     * @param {string} region - Region name
     */
    setActiveRegion(region) {
        AppState.set('activeRegion', region);
        
        // Update UI
        const selector = document.getElementById('region-selector');
        if (selector) {
            selector.value = region;
        }
        
        // Update tabs
        document.querySelectorAll('.region-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        
        const activeTab = document.querySelector(`[data-region="${region}"]`);
        if (activeTab) {
            activeTab.classList.add('active');
        }
        
        this.showNotification(`Content zone switched to ${region}`, 'success');
    }

    /**
     * Play a stream
     * @param {string} id - Stream ID
     * @param {string} title - Stream title
     * @param {string} url - Stream URL
     */
    async playStream(id, title, url) {
        try {
            // Validate URL
            if (!InputValidator.validateStreamUrl(url)) {
                throw new Error('Invalid stream URL');
            }
            
            // Switch to player view
            this.changeView('player');
            
            // Load stream
            if (this.components.mainPlayer) {
                await this.components.mainPlayer.loadStream(url, title);
            }
            
        } catch (error) {
            console.error('Failed to play stream:', error);
            this.showNotification(ErrorHandler.handleStreamError(error, url), 'error');
        }
    }

    /**
     * Load custom stream from input
     */
    async loadCustomStream() {
        const input = document.getElementById('player-url-input');
        if (!input) return;
        
        const url = input.value.trim();
        if (!url) {
            this.showNotification('Please enter a stream URL', 'error');
            return;
        }
        
        await this.playStream('custom', 'Custom Stream', url);
    }

    /**
     * Load local file
     * @param {Event} event - File input change event
     */
    async loadLocalFile(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        try {
            // Switch to player view
            this.changeView('player');
            
            // Load file
            if (this.components.mainPlayer) {
                await this.components.mainPlayer.loadLocalFile(file);
            }
            
        } catch (error) {
            console.error('Failed to load local file:', error);
            this.showNotification(error.message, 'error');
        }
    }

    /**
     * Load dedicated M3U8 stream
     */
    async loadDedicatedM3U8() {
        const input = document.getElementById('m3u8-url-input');
        if (!input) return;
        
        const url = input.value.trim();
        if (!url) {
            this.showNotification('Please enter an M3U8 URL', 'error');
            return;
        }
        
        if (!url.toLowerCase().includes('.m3u8')) {
            this.showNotification('Please enter a valid M3U8 HLS stream URL', 'error');
            return;
        }
        
        try {
            // Create dedicated player if not exists
            if (!this.components.dedicatedPlayer) {
                this.components.dedicatedPlayer = new VideoPlayer('dedicated-m3u8-video', {
                    isDedicated: true
                });
            }
            
            // Show container
            const container = document.getElementById('m3u8-video-container');
            if (container) {
                container.classList.remove('hidden');
            }
            
            // Load stream
            await this.components.dedicatedPlayer.loadStream(url, 'Dedicated M3U8 Stream');
            
        } catch (error) {
            console.error('Failed to load M3U8 stream:', error);
            this.showNotification(ErrorHandler.handleStreamError(error, url), 'error');
        }
    }

    /**
     * Update picture settings
     */
    updatePictureSettings() {
        const brightness = document.getElementById('brightness-slider')?.value || 100;
        const contrast = document.getElementById('contrast-slider')?.value || 100;
        const saturation = document.getElementById('saturation-slider')?.value || 100;
        
        const settings = { brightness, contrast, saturation };
        
        // Update state
        AppState.set('pictureSettings', settings);
        
        // Apply to main player
        if (this.components.mainPlayer) {
            this.components.mainPlayer.applyPictureSettings(settings);
        }
    }

    /**
     * Reset picture settings
     */
    resetPictureSettings() {
        const sliders = ['brightness', 'contrast', 'saturation'];
        
        sliders.forEach(type => {
            const slider = document.getElementById(`${type}-slider`);
            const valueDisplay = document.getElementById(`${type}-value`);
            
            if (slider && valueDisplay) {
                slider.value = 100;
                valueDisplay.textContent = '100%';
            }
        });
        
        this.updatePictureSettings();
        this.showNotification('Picture settings reset to default', 'success');
    }

    /**
     * Toggle VPN status
     */
    toggleVPN() {
        const currentStatus = AppState.get('isVpnOn');
        const newStatus = !currentStatus;
        
        AppState.set('isVpnOn', newStatus);
        
        // Update UI
        const vpnStatus = document.getElementById('vpn-status');
        if (vpnStatus) {
            if (newStatus) {
                vpnStatus.textContent = 'VPN: ON';
                vpnStatus.classList.remove('bg-red-600');
                vpnStatus.classList.add('bg-green-600');
                this.showNotification('VPN Activated. Content geo-restrictions may be lifted.', 'success');
            } else {
                vpnStatus.textContent = 'VPN: OFF';
                vpnStatus.classList.remove('bg-green-600');
                vpnStatus.classList.add('bg-red-600');
                this.showNotification('VPN Deactivated. Current content zone is applied.', 'info');
            }
        }
    }

    /**
     * Add item to watchlist
     * @param {object} item - Stream item
     */
    async addToWatchlist(item) {
        try {
            // Add to state (this will trigger Firebase save if initialized)
            const watchlist = AppState.get('watchlist') || new Map();
            watchlist.set(item.id, item);
            AppState.set('watchlist', watchlist);
            
            this.showNotification(`Added ${item.title} to My List!`, 'success');
            
        } catch (error) {
            console.error('Failed to add to watchlist:', error);
            this.showNotification('Failed to save to watchlist', 'error');
        }
    }

    /**
     * Remove item from watchlist
     * @param {string} itemId - Item ID
     */
    async removeFromWatchlist(itemId) {
        try {
            // Remove from state
            const watchlist = AppState.get('watchlist') || new Map();
            watchlist.delete(itemId);
            AppState.set('watchlist', watchlist);
            
            this.showNotification('Removed item from My List', 'success');
            
        } catch (error) {
            console.error('Failed to remove from watchlist:', error);
            this.showNotification('Failed to remove from watchlist', 'error');
        }
    }

    /**
     * Initialize Firebase (if configuration available)
     */
    async initializeFirebase() {
        // Firebase initialization would go here
        // For now, we'll use local storage for watchlist
        console.log('Firebase initialization skipped - using local storage');
    }

    /**
     * Register service worker for PWA functionality
     */
    async registerServiceWorker() {
        if ('serviceWorker' in navigator) {
            try {
                const registration = await navigator.serviceWorker.register('/sw.js');
                console.log('Service Worker registered:', registration);
            } catch (error) {
                console.warn('Service Worker registration failed:', error);
            }
        }
    }

    /**
     * Show notification
     * @param {string} message - Message to show
     * @param {string} type - Notification type
     */
    showNotification(message, type = 'info') {
        const messageBox = document.getElementById('message-box');
        if (!messageBox) return;
        
        // Sanitize message
        const sanitizedMessage = InputValidator.sanitizeText(message);
        
        messageBox.textContent = sanitizedMessage;
        messageBox.style.backgroundColor = type === 'error' ? '#E50914' : 
                                          type === 'success' ? '#4CAF50' : '#2196F3';
        messageBox.style.opacity = 1;
        messageBox.style.display = 'block';
        
        clearTimeout(messageBox.timer);
        messageBox.timer = setTimeout(() => {
            messageBox.style.opacity = 0;
            setTimeout(() => messageBox.style.display = 'none', 300);
        }, 4000);
    }
}

// Initialize app when script loads
const app = new StreamHubApp();

// Expose app globally for debugging
if (EnvironmentConfig.get('enableLogging')) {
    window.StreamHubApp = app;
    window.AppState = AppState;
}

export default StreamHubApp;
