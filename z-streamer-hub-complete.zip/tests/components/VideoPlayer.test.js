/**
 * @jest-environment jsdom
 */
import VideoPlayer from '../src/components/VideoPlayer.js';

// Mock Video.js
global.videojs = jest.fn(() => ({
    on: jest.fn(),
    el: () => ({
        querySelector: () => ({
            style: {}
        })
    }),
    src: jest.fn(),
    load: jest.fn(),
    play: jest.fn(),
    pause: jest.fn(),
    dispose: jest.fn(),
    error: () => null
}));

// Mock HLS.js
global.Hls = {
    isSupported: () => true,
    Events: {
        ERROR: 'hlsError',
        MANIFEST_PARSED: 'hlsManifestParsed',
        MANIFEST_LOADED: 'hlsManifestLoaded'
    },
    ErrorTypes: {
        NETWORK_ERROR: 'networkError',
        MEDIA_ERROR: 'mediaError'
    }
};

global.Hls.prototype = {
    constructor: global.Hls,
    loadSource: jest.fn(),
    attachMedia: jest.fn(),
    on: jest.fn(),
    destroy: jest.fn()
};

describe('VideoPlayer', () => {
    let container;
    let player;

    beforeEach(() => {
        // Create container element
        container = document.createElement('div');
        container.id = 'test-video-player';
        document.body.appendChild(container);
        
        // Create video element
        const video = document.createElement('video');
        video.id = 'test-video-player';
        container.appendChild(video);
    });

    afterEach(() => {
        if (player) {
            player.dispose();
        }
        document.body.removeChild(container);
        jest.clearAllMocks();
    });

    describe('Initialization', () => {
        test('should initialize with default options', async () => {
            player = new VideoPlayer('test-video-player');
            
            expect(player.containerId).toBe('test-video-player');
            expect(player.options.autoplay).toBe(false);
            expect(player.options.controls).toBe(true);
        });

        test('should accept custom options', async () => {
            player = new VideoPlayer('test-video-player', {
                autoplay: true,
                isDedicated: true
            });
            
            expect(player.options.autoplay).toBe(true);
            expect(player.isDedicated).toBe(true);
        });
    });

    describe('Stream Loading', () => {
        beforeEach(async () => {
            player = new VideoPlayer('test-video-player');
            // Wait for initialization
            await new Promise(resolve => setTimeout(resolve, 100));
        });

        test('should detect HLS streams correctly', () => {
            expect(player.isHLSStream('https://example.com/stream.m3u8')).toBe(true);
            expect(player.isHLSStream('https://example.com/video.mp4')).toBe(false);
        });

        test('should get correct MIME types', () => {
            expect(player.getMimeType('test.mp4')).toBe('video/mp4');
            expect(player.getMimeType('test.webm')).toBe('video/webm');
            expect(player.getMimeType('test.m3u8')).toBe('application/x-mpegURL');
            expect(player.getMimeType('unknown.xyz')).toBe('video/mp4'); // fallback
        });

        test('should validate URLs before loading', async () => {
            const result = await player.loadStream('invalid-url', 'Test');
            
            expect(result.success).toBe(false);
            expect(result.error).toContain('Invalid');
        });

        test('should handle valid MP4 streams', async () => {
            const result = await player.loadStream('https://example.com/video.mp4', 'Test Video');
            
            expect(result.success).toBe(true);
            expect(player.currentStream).toBe('https://example.com/video.mp4');
        });
    });

    describe('File Loading', () => {
        beforeEach(async () => {
            player = new VideoPlayer('test-video-player');
            await new Promise(resolve => setTimeout(resolve, 100));
        });

        test('should validate files before loading', async () => {
            const invalidFile = {
                size: 600 * 1024 * 1024, // Too large
                type: 'video/mp4'
            };

            try {
                await player.loadLocalFile(invalidFile);
            } catch (error) {
                expect(error.message).toContain('size exceeds');
            }
        });

        test('should load valid video files', async () => {
            // Mock URL.createObjectURL
            global.URL.createObjectURL = jest.fn(() => 'blob:mock-url');
            global.URL.revokeObjectURL = jest.fn();

            const validFile = {
                size: 1024 * 1024, // 1MB
                type: 'video/mp4',
                name: 'test-video.mp4'
            };

            const result = await player.loadLocalFile(validFile);
            
            expect(result.success).toBe(true);
            expect(global.URL.createObjectURL).toHaveBeenCalledWith(validFile);
        });
    });

    describe('Picture Settings', () => {
        beforeEach(async () => {
            player = new VideoPlayer('test-video-player');
            await new Promise(resolve => setTimeout(resolve, 100));
        });

        test('should apply picture settings', () => {
            const settings = {
                brightness: 120,
                contrast: 80,
                saturation: 110
            };

            player.applyPictureSettings(settings);
            
            // Since we're mocking the video element, we can't test the actual style
            // but we can verify the method doesn't throw
            expect(() => player.applyPictureSettings(settings)).not.toThrow();
        });
    });

    describe('Cleanup', () => {
        beforeEach(async () => {
            player = new VideoPlayer('test-video-player');
            await new Promise(resolve => setTimeout(resolve, 100));
        });

        test('should clean up resources on dispose', () => {
            player.dispose();
            
            expect(player.player).toBeNull();
        });
    });
});
