/**
 * @jest-environment jsdom
 */
import AppState from '../src/state/appState.js';

describe('AppState', () => {
    let appState;
    
    beforeEach(() => {
        // Create a fresh instance for each test
        appState = new (await import('../src/state/appState.js')).default.constructor();
    });

    describe('Basic State Management', () => {
        test('should set and get simple state values', () => {
            appState.set('testKey', 'testValue');
            expect(appState.get('testKey')).toBe('testValue');
        });

        test('should handle nested state paths', () => {
            appState.set('user.name', 'John Doe');
            appState.set('user.email', 'john@example.com');
            
            expect(appState.get('user.name')).toBe('John Doe');
            expect(appState.get('user.email')).toBe('john@example.com');
            expect(appState.get('user')).toEqual({
                name: 'John Doe',
                email: 'john@example.com'
            });
        });

        test('should return undefined for non-existent keys', () => {
            expect(appState.get('nonExistent')).toBeUndefined();
            expect(appState.get('nested.nonExistent')).toBeUndefined();
        });
    });

    describe('Subscriptions', () => {
        test('should notify subscribers when state changes', (done) => {
            const callback = jest.fn((newValue, oldValue) => {
                expect(newValue).toBe('newValue');
                expect(oldValue).toBeUndefined();
                expect(callback).toHaveBeenCalledTimes(1);
                done();
            });

            appState.subscribe('testKey', callback);
            appState.set('testKey', 'newValue');
        });

        test('should support multiple subscribers', () => {
            const callback1 = jest.fn();
            const callback2 = jest.fn();

            appState.subscribe('testKey', callback1);
            appState.subscribe('testKey', callback2);
            appState.set('testKey', 'value');

            expect(callback1).toHaveBeenCalledWith('value', undefined, {});
            expect(callback2).toHaveBeenCalledWith('value', undefined, {});
        });

        test('should support unsubscribe', () => {
            const callback = jest.fn();
            const unsubscribe = appState.subscribe('testKey', callback);
            
            appState.set('testKey', 'value1');
            expect(callback).toHaveBeenCalledTimes(1);
            
            unsubscribe();
            appState.set('testKey', 'value2');
            expect(callback).toHaveBeenCalledTimes(1); // Should not be called again
        });
    });

    describe('Update Method', () => {
        test('should update state using a function', () => {
            appState.set('counter', 0);
            
            appState.update('counter', (current) => current + 1);
            expect(appState.get('counter')).toBe(1);
            
            appState.update('counter', (current) => current * 2);
            expect(appState.get('counter')).toBe(2);
        });

        test('should handle undefined current values', () => {
            appState.update('newKey', (current) => (current || 0) + 5);
            expect(appState.get('newKey')).toBe(5);
        });
    });

    describe('Middleware', () => {
        test('should run middleware before state changes', () => {
            const middleware = jest.fn((key, newValue, oldValue) => {
                expect(key).toBe('testKey');
                expect(newValue).toBe('newValue');
                expect(oldValue).toBeUndefined();
                return true; // Allow change
            });

            appState.addMiddleware(middleware);
            appState.set('testKey', 'newValue');

            expect(middleware).toHaveBeenCalled();
            expect(appState.get('testKey')).toBe('newValue');
        });

        test('should block state changes when middleware returns false', () => {
            const middleware = jest.fn(() => false); // Block change

            appState.addMiddleware(middleware);
            appState.set('testKey', 'blockedValue');

            expect(middleware).toHaveBeenCalled();
            expect(appState.get('testKey')).toBeUndefined();
        });
    });

    describe('Reset Functionality', () => {
        test('should reset state to initial values', () => {
            appState.set('testKey', 'testValue');
            appState.set('anotherKey', 'anotherValue');
            
            expect(appState.get('testKey')).toBe('testValue');
            
            appState.reset();
            
            expect(appState.get('testKey')).toBeUndefined();
            expect(appState.get('activeRegion')).toBe('USA'); // Should be back to default
        });
    });

    describe('Wildcard Subscriptions', () => {
        test('should support wildcard subscriptions', (done) => {
            const callback = jest.fn((newValue, oldValue) => {
                expect(newValue).toBe('value');
                done();
            });

            appState.subscribe('user.*', callback);
            appState.set('user.name', 'value');
        });

        test('should support global wildcard', () => {
            const callback = jest.fn();

            appState.subscribe('*', callback);
            appState.set('anyKey', 'anyValue');
            appState.set('anotherKey', 'anotherValue');

            expect(callback).toHaveBeenCalledTimes(2);
        });
    });
});
